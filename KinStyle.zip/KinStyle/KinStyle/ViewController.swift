//
//  ViewController.swift
//  KinStyle
//
//  Created by kinjal kathiriya  on  2/16/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

