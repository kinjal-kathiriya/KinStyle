//
//  Welcome.swift
//  KinStyle
//
//  Created by kinjal kathiriya  on 2/16/25.
//

import UIKit

class Welcome1ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}



