//
//  KinStyleTests.swift
//  KinStyleTests
//
//  Created by kinjal kathiriya  on 3/9/25.
//

import Testing
@testable import KinStyle

struct KinStyleTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
